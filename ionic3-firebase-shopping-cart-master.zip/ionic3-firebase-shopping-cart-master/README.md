This repository is part of an ionic tutorial that explains how to create ionic 3 ecommerce with firebase

Check the complete step by step tutorial in: http://www.developerslearnit.com/2018/01/building-ionic-3-shopping-cart-app-with-firebase-realtime-database-part-1.html

![](https://res.cloudinary.com/panachora/image/upload/v1532358973/banner_owgng9.png)

## Installation

Install  dependencies
```sh
npm install
```
## Run the ionic app

The plugins required in this app use cordova, so it will not work in the browser. You need to try it on a real device or on an emulator
```sh
ionic cordova platform add android
ionic cordova run android
```
