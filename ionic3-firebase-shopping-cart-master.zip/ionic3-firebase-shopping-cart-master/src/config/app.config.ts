export const config = {
     showCategory: true,
     firebasConfig: {
          apiKey: "AIzaSyCW7hwYvB3b1qpR6VLNb-eGOhXklP-oAuU",
          authDomain: "ionic-firebase-cart.firebaseapp.com",
          databaseURL: "https://ionic-firebase-cart.firebaseio.com",
          projectId: "ionic-firebase-cart",
          storageBucket: "ionic-firebase-cart.appspot.com",
          messagingSenderId: "539859030675"
     }
};